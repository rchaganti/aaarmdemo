function ParseItem($jsonItem) {
    if($jsonItem.Type -eq "Array") {
        return ParseJsonArray($jsonItem)
    }
    elseif($jsonItem.Type -eq "Object") {
        return ParseJsonObject($jsonItem)
    }
    else {
        return $jsonItem.ToString()
    }
}

function ParseJsonObject($jsonObj) {
    $result = @{}
    $jsonObj.Keys | ForEach-Object {
        $key = $_
        $item = $jsonObj[$key]
        $parsedItem = ParseItem $item
        $result.Add($key,$parsedItem)
    }
    return $result
}

function ParseJsonArray($jsonArray) {
    $result = @()
    $jsonArray | ForEach-Object {
        $parsedItem = ParseItem $_
        $result += $parsedItem
    }
    return $result
}

function ParseJsonString($json) {
    $config = [Newtonsoft.Json.Linq.JObject]::Parse($json)
    return ParseJsonObject($config)
}

function ParseJsonFile($fileName) {
    $json = (Get-Content $FileName | Out-String)
    return ParseJsonString $json
}

# Create the function to create the authorization signature
Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}

Function Push-OMSdata
{
    [CmdletBinding()]
    param (
        [String] $CustomerId,
        [String] $SharedKey,
        [String] $LogType,
        $Body,
        [String] $TimeFieldStamp
    )

    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -fileName $fileName `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
        "time-generated-field" = $TimeStampField;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode
}

Function Send-PEDRACLog
{
    [CmdletBinding()]
    param (
        [String] $CustomerId,
        [String] $SharedKey,
        [PSCredential] $Credential,
        [String[]] $DRACIPAddress
    )

    foreach ($IPAddress in $DRACIPAddress)
    {
        $lcData = (Get-PELCLogEntry -DRACIPAddress $IPAddress -Credential $Credential)

        if ($lcData)
        {
            foreach ($log in $lcData)
            {
                $timeStampField = (Get-Date $log.CreationTime -Format yyyy-MM-ddThh:mm:ssZ).ToString()
                $log.Remove('CreationTime')
                $body = $log | ConvertTo-Json
                Push-OMSdata -CustomerId $CustomerId -SharedKey $SharedKey -LogType "PowerEdgeLCLog" -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -TimeFieldStamp $timeStampField -Verbose
            }
        }

        $seData = (Get-PESELLogEntry -DRACIPAddress $IPAddress -Credential $Credential)

        if ($seData)
        {
            foreach ($log in $seData)
            {
                $timeStampField = (Get-Date $log.CreationTime -Format yyyy-MM-ddThh:mm:ssZ).ToString()
                $log.Remove('CreationTime')
                $body = $log | ConvertTo-Json
                Push-OMSdata -CustomerId $CustomerId -SharedKey $SharedKey -LogType 'PowerEdgeSELog' -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -TimeFieldStamp $timeStampField -Verbose
            }
        }
    }
}

function Get-PELCLogEntry
{
    param (
        [String] $DRACIPAddress,
        [PSCredential] $Credential
    )
    $logEntries = @()
    $cimSessionOption = New-CimSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck -Encoding Utf8 -UseSsl
    $cimSession = New-CimSession -Authentication Basic -Credential $Credential -ComputerName $DRACIPAddress -Port 443 -SessionOption $cimSessionOption
    $lcLog = Get-CimInstance -CimSession $cimSession -ClassName DCIM_LCLogEntry -Namespace root\dcim -errorAction SilentlyContinue

    if ($lcLog)
    {
        foreach ($log in $lcLog)
        {
            $lcHash = @{
                'InstanceID' = $log.InstanceID
                'Category' = $log.Category
                'PerceivedSeverity' = $log.PerceivedSeverity
                'Message' = $log.Message
                'CreationTime' = ([System.Management.ManagementDateTimeConverter]::ToDateTime($log.CreationTimeStamp)).ToString()
                'BMCAddress' = $DRACIPAddress
                'Component' = $(($log.ElementName)[0..2] -join '')
            }
            $logEntries += $lcHash
        }
        return $logEntries
    }

    return $lcLog
}

function Get-PESELLogEntry
{
    param (
        [String] $DRACIPAddress,
        [PSCredential] $Credential
    )
    $logEntries = @()
    $cimSessionOption = New-CimSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck -Encoding Utf8 -UseSsl
    $cimSession = New-CimSession -Authentication Basic -Credential $Credential -ComputerName $DRACIPAddress -Port 443 -SessionOption $cimSessionOption
    $selLog = Get-CimInstance -CimSession $cimSession -ClassName DCIM_SELLogEntry -Namespace root\dcim -errorAction SilentlyContinue

    if ($selLog)
    {
        foreach ($log in $selLog)
        {
            $selHash = @{
                'InstanceID' = $log.InstanceID
                'PerceivedSeverity' = $log.PerceivedSeverity
                'Message' = $log.RecordData
                'CreationTime' = ([System.Management.ManagementDateTimeConverter]::ToDateTime($log.CreationTimeStamp)).ToString()
                'BMCAddress' = $DRACIPAddress
            }
            $logEntries += $selHash
        }
        return $logEntries
    }
}

function Get-PEPowerReading
{
    param (
        [String] $DRACIPAddress,
        [PSCredential] $Credential
    )

    $cimSessionOption = New-CimSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck -Encoding Utf8 -UseSsl
    $cimSession = New-CimSession -Authentication Basic -Credential $Credential -ComputerName $DRACIPAddress -Port 443 -SessionOption $cimSessionOption
    $powerReading = Get-CimInstance -CimSession $cimSession -ClassName DCIM_PSNumericSensor -Namespace root\dcim -errorAction SilentlyContinue

    return $powerReading
}

Export-ModuleMember -Function *